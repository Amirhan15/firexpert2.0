# Справочные материалы (materials.tsx)

```typescript
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export function Materials() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Справочные материалы</CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="general">
          <TabsList>
            <TabsTrigger value="general">Общие сведения</TabsTrigger>
            <TabsTrigger value="tactics">Тактика тушения</TabsTrigger>
            <TabsTrigger value="calculations">Расчеты</TabsTrigger>
          </TabsList>

          <TabsContent value="general">
            <ScrollArea className="h-[600px] p-4">
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Основные понятия</h3>
                <p>
                  Справочные материалы по пожаротушению и тактике...
                  {/* Content would be populated from the API */}
                </p>
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="tactics">
            <ScrollArea className="h-[600px] p-4">
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Тактика тушения пожаров</h3>
                <p>
                  Материалы по тактике тушения различных видов пожаров...
                  {/* Content would be populated from the API */}
                </p>
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="calculations">
            <ScrollArea className="h-[600px] p-4">
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Расчетные формулы</h3>
                <p>
                  Формулы и методики расчета...
                  {/* Content would be populated from the API */}
                </p>
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
```
