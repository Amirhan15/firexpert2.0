# Генератор задач (task-generator.tsx)

```typescript
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { HintSystem } from "@/components/hints/hint-system";

type TaskVariable = {
  name: string;
  range: [number, number];
};

type TaskTemplate = {
  text: string;
  variables: TaskVariable[];
  solution: (vars: Record<string, number>) => number;
  explanation: (vars: Record<string, number>, result: number) => string;
};

type TaskCategory = {
  [key: string]: TaskTemplate[];
};

function getRandomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

const taskDatabase: TaskCategory = {
  "Путь пройденный огнем": [
    {
      text: "Определить путь пройденный огнем, если Vлин={vLin} м/мин; tсл = {tSl} мин; tб.р.= {tBr} мин.",
      variables: [
        { name: "vLin", range: [1, 8] },
        { name: "tSl", range: [3, 15] },
        { name: "tBr", range: [3, 8] }
      ],
      solution: (vars) => vars.vLin * (vars.tSl + vars.tBr),
      explanation: (vars, result) => 
        `L = Vлин × (tсл + tб.р) = ${vars.vLin} × (${vars.tSl} + ${vars.tBr}) = ${result} метров`
    }
  ],
  "Площадь пожара": [
    {
      text: "В центре помещения размером {length} x {width} м произошло возгорание. Найдите площадь пожара на момент подачи первого ствола, если известно, что tсл = {tSl} мин, tб.р. = {tBr} мин.",
      variables: [
        { name: "length", range: [10, 60] },
        { name: "width", range: [10, 30] },
        { name: "tSl", range: [3, 15] },
        { name: "tBr", range: [3, 8] }
      ],
      solution: (vars) => Math.PI * Math.pow((vars.tSl + vars.tBr) * 1.5, 2),
      explanation: (vars, result) => 
        `Sп = π × R² = 3.14 × (${vars.tSl + vars.tBr} × 1.5)² = ${result.toFixed(2)} м²`
    }
  ]
};

export function TaskGenerator() {
  const { toast } = useToast();
  const [category, setCategory] = useState<string>("");
  const [currentTask, setCurrentTask] = useState<{
    text: string;
    correctAnswer: number;
    explanation: string;
  } | null>(null);
  const [answer, setAnswer] = useState("");

  const generateTask = async () => {
    try {
      const templates = taskDatabase[category];
      if (!templates || templates.length === 0) {
        throw new Error("Нет доступных задач в этой категории");
      }

      // Выбираем случайный шаблон задачи из категории
      const template = templates[Math.floor(Math.random() * templates.length)];

      // Генерируем значения переменных
      const variables: Record<string, number> = {};
      template.variables.forEach(variable => {
        variables[variable.name] = getRandomInt(variable.range[0], variable.range[1]);
      });

      // Подставляем значения в текст задачи
      let taskText = template.text;
      Object.entries(variables).forEach(([name, value]) => {
        taskText = taskText.replace(`{${name}}`, value.toString());
      });

      // Вычисляем правильный ответ
      const correctAnswer = template.solution(variables);
      const explanation = template.explanation(variables, correctAnswer);

      const response = await apiRequest("POST", "/api/tasks", {
        category,
        taskData: {
          text: taskText,
          variables,
          correctAnswer,
          explanation
        },
      });

      const task = await response.json();
      setCurrentTask({
        text: taskText,
        correctAnswer,
        explanation
      });
      setAnswer("");
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Не удалось сгенерировать задачу",
        variant: "destructive",
      });
    }
  };

  const checkAnswer = async () => {
    if (!currentTask || !answer) return;

    try {
      const userAnswer = parseFloat(answer);
      const isCorrect = Math.abs(userAnswer - currentTask.correctAnswer) < 0.1;

      toast({
        title: isCorrect ? "Правильно!" : "Неправильно",
        description: isCorrect ? "Отличная работа!" : currentTask.explanation,
        variant: isCorrect ? "default" : "destructive",
      });

      await apiRequest("POST", "/api/tasks", {
        answer: userAnswer,
        isCorrect,
      });
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Не удалось проверить ответ",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Генератор задач</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Select value={category} onValueChange={setCategory}>
            <SelectTrigger>
              <SelectValue placeholder="Выберите тему" />
            </SelectTrigger>
            <SelectContent>
              {Object.keys(taskDatabase).map((cat) => (
                <SelectItem key={cat} value={cat}>
                  {cat}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Button onClick={generateTask} disabled={!category}>
            Сгенерировать задачу
          </Button>

          {currentTask && (
            <div className="space-y-4">
              <div className="p-4 bg-muted rounded-lg">
                <p>{currentTask.text}</p>
              </div>

              <HintSystem 
                taskType={category} 
                currentStep={0}
              />

              <div>
                <Input
                  placeholder="Введите ваш ответ"
                  value={answer}
                  onChange={(e) => setAnswer(e.target.value)}
                />
              </div>

              <Button onClick={checkAnswer} disabled={!answer}>
                Проверить ответ
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
```
