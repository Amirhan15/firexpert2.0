import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Sun, Moon, LogOut } from "lucide-react";
import { useTheme } from "@/hooks/use-theme";

type Tab = "tasks" | "materials" | "calculator" | "history" | "statistics";

interface HeaderProps {
  activeTab: Tab;
  onTabChange: (tab: Tab) => void;
}

const tabs: { id: Tab; label: string }[] = [
  { id: "tasks", label: "Решение задач" },
  { id: "materials", label: "Справочные материалы" },
  { id: "calculator", label: "Калькулятор" },
  { id: "history", label: "История решений" },
  { id: "statistics", label: "Статистика" },
];

export function Header({ activeTab, onTabChange }: HeaderProps) {
  const { logoutMutation } = useAuth();
  const { theme, setTheme } = useTheme();

  return (
    <header className="border-b">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <h1 className="text-2xl font-bold">FIREXPERT</h1>

          <nav className="hidden md:flex space-x-4">
            {tabs.map((tab) => (
              <Button
                key={tab.id}
                variant={activeTab === tab.id ? "default" : "ghost"}
                onClick={() => onTabChange(tab.id)}
              >
                {tab.label}
              </Button>
            ))}
          </nav>

          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setTheme(theme === "light" ? "dark" : "light")}
            >
              {theme === "light" ? (
                <Moon className="h-5 w-5" />
              ) : (
                <Sun className="h-5 w-5" />
              )}
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => logoutMutation.mutate()}
            >
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
