import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Chart } from "@/components/ui/chart";
import { Task } from "@shared/schema";

export function Statistics() {
  const { data: tasks } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
  });

  const calculateStats = () => {
    if (!tasks?.length) return null;

    const total = tasks.length;
    const correct = tasks.filter((t) => t.isCorrect).length;
    const percentage = Math.round((correct / total) * 100);

    const byCategory = tasks.reduce((acc, task) => {
      acc[task.category] = acc[task.category] || {
        total: 0,
        correct: 0,
      };
      acc[task.category].total++;
      if (task.isCorrect) acc[task.category].correct++;
      return acc;
    }, {} as Record<string, { total: number; correct: number }>);

    return { total, correct, percentage, byCategory };
  };

  const stats = calculateStats();

  if (!stats) return <div>Нет данных для анализа</div>;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Общая статистика</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <p className="text-sm font-medium">
                Общий прогресс: {stats.percentage}%
              </p>
              <Progress value={stats.percentage} className="mt-2" />
            </div>
            <div>
              <p>Всего решено задач: {stats.total}</p>
              <p>Правильных ответов: {stats.correct}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Статистика по категориям</CardTitle>
        </CardHeader>
        <CardContent>
          {Object.entries(stats.byCategory).map(([category, data]) => (
            <div key={category} className="mb-4">
              <p className="text-sm font-medium">{category}</p>
              <Progress
                value={(data.correct / data.total) * 100}
                className="mt-2"
              />
              <p className="text-sm text-muted-foreground mt-1">
                {data.correct} из {data.total} правильно
              </p>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
