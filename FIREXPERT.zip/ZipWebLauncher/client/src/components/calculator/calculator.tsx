import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Info } from "lucide-react";

type Calculation = {
  type: string;
  formula: string;
  description: string;
  inputs: {
    name: string;
    label: string;
    unit: string;
  }[];
};

const calculations: Calculation[] = [
  {
    type: "pathLength",
    formula: "L = Vлин × (tсл + tб.р)",
    description: "Расчет пути пройденного огнем",
    inputs: [
      { name: "vLin", label: "Линейная скорость (Vлин)", unit: "м/мин" },
      { name: "tSl", label: "Время следования (tсл)", unit: "мин" },
      { name: "tBr", label: "Время боевого развертывания (tб.р)", unit: "мин" },
    ],
  },
  {
    type: "fireArea",
    formula: "Sп = π × (R)²",
    description: "Расчет площади пожара (круговая форма)",
    inputs: [
      { name: "radius", label: "Радиус пожара (R)", unit: "м" },
    ],
  },
  {
    type: "waterFlow",
    formula: "Qтр = Sт × Iтр",
    description: "Расчет требуемого расхода воды",
    inputs: [
      { name: "area", label: "Площадь тушения (Sт)", unit: "м²" },
      { name: "intensity", label: "Интенсивность подачи (Iтр)", unit: "л/с×м²" },
    ],
  },
];

type HistoryEntry = {
  type: string;
  inputs: Record<string, number>;
  result: number;
  timestamp: Date;
};

export function Calculator() {
  const [selectedType, setSelectedType] = useState("");
  const [inputs, setInputs] = useState<Record<string, string>>({});
  const [result, setResult] = useState<number | null>(null);
  const [history, setHistory] = useState<HistoryEntry[]>([]);

  const selectedCalculation = calculations.find((c) => c.type === selectedType);

  const handleInputChange = (name: string, value: string) => {
    setInputs((prev) => ({ ...prev, [name]: value }));
  };

  const calculateResult = () => {
    if (!selectedCalculation) return;

    const numericInputs: Record<string, number> = {};
    for (const input of selectedCalculation.inputs) {
      const value = parseFloat(inputs[input.name]);
      if (isNaN(value)) return;
      numericInputs[input.name] = value;
    }

    let calculatedResult: number;
    switch (selectedType) {
      case "pathLength":
        calculatedResult = numericInputs.vLin * (numericInputs.tSl + numericInputs.tBr);
        break;
      case "fireArea":
        calculatedResult = Math.PI * Math.pow(numericInputs.radius, 2);
        break;
      case "waterFlow":
        calculatedResult = numericInputs.area * numericInputs.intensity;
        break;
      default:
        return;
    }

    setResult(calculatedResult);
    setHistory((prev) => [
      {
        type: selectedType,
        inputs: numericInputs,
        result: calculatedResult,
        timestamp: new Date(),
      },
      ...prev.slice(0, 9), // Keep last 10 calculations
    ]);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            Калькулятор пожарно-технических расчетов
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <Select value={selectedType} onValueChange={setSelectedType}>
            <SelectTrigger>
              <SelectValue placeholder="Выберите тип расчета" />
            </SelectTrigger>
            <SelectContent>
              {calculations.map((calc) => (
                <SelectItem key={calc.type} value={calc.type}>
                  {calc.description}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {selectedCalculation && (
            <>
              <div className="p-4 bg-muted rounded-lg space-y-2">
                <div className="flex items-center gap-2">
                  <Info className="h-4 w-4" />
                  <p className="font-mono">{selectedCalculation.formula}</p>
                </div>
                <p className="text-sm text-muted-foreground">
                  {selectedCalculation.description}
                </p>
              </div>

              <div className="grid gap-4">
                {selectedCalculation.inputs.map((input) => (
                  <div key={input.name} className="grid gap-1.5">
                    <label className="text-sm font-medium">{input.label}</label>
                    <div className="flex gap-2 items-center">
                      <Input
                        type="number"
                        value={inputs[input.name] || ""}
                        onChange={(e) => handleInputChange(input.name, e.target.value)}
                      />
                      <span className="text-sm text-muted-foreground w-16">
                        {input.unit}
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              <Button onClick={calculateResult}>Рассчитать</Button>

              {result !== null && (
                <div className="p-4 bg-primary/5 rounded-lg">
                  <p className="font-mono text-lg">
                    Результат: {result.toFixed(2)}
                  </p>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>

      {history.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>История расчетов</CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[200px]">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Время</TableHead>
                    <TableHead>Тип расчета</TableHead>
                    <TableHead>Параметры</TableHead>
                    <TableHead>Результат</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {history.map((entry, index) => {
                    const calc = calculations.find((c) => c.type === entry.type);
                    return (
                      <TableRow key={index}>
                        <TableCell>
                          {entry.timestamp.toLocaleTimeString()}
                        </TableCell>
                        <TableCell>{calc?.description}</TableCell>
                        <TableCell>
                          {calc?.inputs
                            .map(
                              (input) =>
                                `${input.label}: ${entry.inputs[input.name]} ${
                                  input.unit
                                }`,
                            )
                            .join(", ")}
                        </TableCell>
                        <TableCell>{entry.result.toFixed(2)}</TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </ScrollArea>
          </CardContent>
        </Card>
      )}
    </div>
  );
}