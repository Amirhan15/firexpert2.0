import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Lightbulb, ChevronRight } from "lucide-react";

interface HintProps {
  taskType: string;
  currentStep: number;
}

type HintStep = {
  title: string;
  description: string;
  formula?: string;
};

type HintCategory = {
  [key: string]: HintStep[];
};

const hints: HintCategory = {
  "Путь пройденный огнем": [
    {
      title: "Определение исходных данных",
      description: "Выпишите все данные из условия задачи: линейную скорость распространения огня (Vлин), время следования (tсл), время боевого развертывания (tб.р).",
    },
    {
      title: "Формула расчета",
      description: "Для расчета пути, пройденного огнем, используйте формулу:",
      formula: "L = Vлин × (tсл + tб.р)",
    },
    {
      title: "Проверка размерностей",
      description: "Убедитесь, что все величины переведены в нужные единицы измерения: Vлин (м/мин), tсл и tб.р (мин). Результат будет в метрах.",
    },
  ],
  "Площадь пожара": [
    {
      title: "Определение формы пожара",
      description: "Определите геометрическую форму пожара (круг, полукруг, прямоугольник) в зависимости от места возникновения.",
    },
    {
      title: "Расчет радиуса",
      description: "Рассчитайте радиус пожара по формуле:",
      formula: "R = L = Vлин × (tсл + tб.р)",
    },
    {
      title: "Расчет площади",
      description: "В зависимости от формы пожара используйте соответствующую формулу:",
      formula: "Круг: Sп = πR²\nПолукруг: Sп = πR²/2\nПрямоугольник: Sп = a × b",
    },
  ],
};

export function HintSystem({ taskType, currentStep }: HintProps) {
  const [showHints, setShowHints] = useState(false);
  const [currentHint, setCurrentHint] = useState(0);

  const taskHints = hints[taskType] || [];

  const showNextHint = () => {
    if (currentHint < taskHints.length - 1) {
      setCurrentHint(currentHint + 1);
    }
  };

  if (!taskHints.length) {
    return null;
  }

  return (
    <div className="space-y-4">
      <Button
        variant="outline"
        className="w-full"
        onClick={() => setShowHints(!showHints)}
      >
        <Lightbulb className="w-4 h-4 mr-2" />
        {showHints ? "Скрыть подсказки" : "Показать подсказки"}
      </Button>

      {showHints && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Подсказки</CardTitle>
            <CardDescription>
              Шаг {currentHint + 1} из {taskHints.length}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[200px] pr-4">
              <div className="space-y-4">
                <h3 className="font-semibold">{taskHints[currentHint].title}</h3>
                <p className="text-sm text-muted-foreground">
                  {taskHints[currentHint].description}
                </p>
                {taskHints[currentHint].formula && (
                  <pre className="p-4 bg-muted rounded-lg font-mono text-sm">
                    {taskHints[currentHint].formula}
                  </pre>
                )}
              </div>
            </ScrollArea>

            {currentHint < taskHints.length - 1 && (
              <Button
                variant="outline"
                size="sm"
                className="mt-4"
                onClick={showNextHint}
              >
                Следующая подсказка
                <ChevronRight className="w-4 h-4 ml-2" />
              </Button>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}