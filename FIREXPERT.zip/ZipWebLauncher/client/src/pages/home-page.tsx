import { useState } from "react";
import { Header } from "@/components/navigation/header";
import { TaskGenerator } from "@/components/task/task-generator";
import { Materials } from "@/components/reference/materials";
import { Calculator } from "@/components/calculator/calculator";
import { History } from "@/components/history/history";
import { Statistics } from "@/components/statistics/statistics";

type ActiveTab = "tasks" | "materials" | "calculator" | "history" | "statistics";

export default function HomePage() {
  const [activeTab, setActiveTab] = useState<ActiveTab>("tasks");

  return (
    <div className="min-h-screen bg-background">
      <Header activeTab={activeTab} onTabChange={setActiveTab} />
      <main className="container mx-auto px-4 py-8">
        {activeTab === "tasks" && <TaskGenerator />}
        {activeTab === "materials" && <Materials />}
        {activeTab === "calculator" && <Calculator />}
        {activeTab === "history" && <History />}
        {activeTab === "statistics" && <Statistics />}
      </main>
    </div>
  );
}
